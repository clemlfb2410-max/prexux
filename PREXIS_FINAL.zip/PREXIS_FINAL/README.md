# PREXIS — Cloud + Local, sans authentification

## Structure
- `app.py` : interface PREXIS + API Flask + PostgreSQL/SQLite + IA + Web + vision + TTS + domotique.
- `local_agent.py` : petit client PC local, uniquement pour des actions prédéfinies.
- `requirements.txt` : dépendances.
- `render.yaml` : Web Service Render + PostgreSQL.

## Render
1. Mets ces fichiers à la racine d'un dépôt GitHub.
2. Dans Render, crée le service depuis le dépôt ou utilise le Blueprint `render.yaml`.
3. Ajoute `OPENAI_API_KEY` dans les variables d'environnement Render.
4. Le Build Command est `pip install -r requirements.txt`.
5. Le Start Command est `gunicorn app:app`.
6. Le service utilise `DATABASE_URL` relié à Render PostgreSQL.

## Local
```bash
python -m pip install -r requirements.txt
python app.py
```
Puis ouvre `http://127.0.0.1:5000`.

Pour activer les commandes PC, dans un second terminal :
```bash
python local_agent.py
```
Puis laisse PREXIS ouvert dans ton navigateur. L'interface essaie `127.0.0.1:8765` uniquement pour le client local.

## Important
Cette version n'a volontairement aucun écran de connexion, aucun nom d'utilisateur et aucun mot de passe d'accès à PREXIS. Elle ne contient donc pas de coffre de mots de passe : exposer un tel coffre sur une API publique sans authentification serait une mauvaise idée.
