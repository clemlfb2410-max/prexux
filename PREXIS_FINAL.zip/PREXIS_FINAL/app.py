import os
import io
import base64
import json
import sqlite3
import datetime as dt
from urllib.parse import urlparse

from flask import Flask, jsonify, render_template_string, request, send_file

try:
    import psycopg
except ImportError:
    psycopg = None

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5").strip()
TTS_MODEL = os.getenv("TTS_MODEL", "gpt-4o-mini-tts").strip()
TTS_VOICE = os.getenv("TTS_VOICE", "onyx").strip()

client = OpenAI(api_key=OPENAI_API_KEY) if (OpenAI and OPENAI_API_KEY) else None

SYSTEM_PROMPT = """
Tu es PREXIS, un assistant personnel futuriste en français, inspiré par une IA de majordome de science-fiction.
Ton style est calme, précis, intelligent, légèrement solennel, mais naturel. Réponds directement à la question.
N'invente pas une information quand tu ne la connais pas. Si la recherche Web est disponible, utilise-la pour les
informations actuelles. Tu peux aider à organiser des tâches, mémoriser des notes, analyser des images, expliquer
du code et piloter les fonctions locales autorisées. Ne prétends jamais avoir exécuté une action locale si le client
local n'est pas connecté. Les réponses doivent rester adaptées à un utilisateur adolescent.
""".strip()

HTML_UI = r'''<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
<meta name="theme-color" content="#05050b">
<title>PREXIS // OVERLORD</title>
<style>
:root{--bg:#05050b;--glass:rgba(18,18,28,.62);--line:rgba(255,255,255,.14);--text:#f5f5f7;--muted:#9b9bab;--pink:#ff2aa3;--cyan:#2ad9ff;--violet:#9b5cff;--green:#49f6a8}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text",Inter,sans-serif}button,input,textarea{font:inherit}button{color:inherit}
#bg{position:fixed;inset:0;width:100%;height:100%;z-index:0}.noise{position:fixed;inset:0;z-index:1;pointer-events:none;background:radial-gradient(circle at 50% 35%,rgba(132,53,255,.13),transparent 32%),radial-gradient(circle at 20% 80%,rgba(255,0,150,.10),transparent 30%)}
.app{position:relative;z-index:2;height:100%;max-width:980px;margin:auto;padding:max(12px,env(safe-area-inset-top)) 14px max(12px,env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:10px}
.top{display:flex;align-items:center;justify-content:space-between}.brand{font-size:12px;letter-spacing:3px;font-weight:800}.status{font-size:10px;color:var(--green);display:flex;align-items:center;gap:6px}.dot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 14px var(--green)}
.hero{min-height:300px;display:flex;align-items:center;justify-content:center;position:relative}.orb{width:260px;height:260px;position:relative;display:grid;place-items:center;cursor:pointer}.core{width:76px;height:76px;border-radius:50%;background:radial-gradient(circle,#fff 0,#ff66ba 27%,#8b3cff 64%,#18002e 100%);box-shadow:0 0 35px #ff2aa3,0 0 85px #8b3cff,0 0 150px rgba(42,217,255,.8);animation:core 1.8s ease-in-out infinite;z-index:5}.wave{position:absolute;border-radius:50%;border:3px solid;opacity:.9;animation:wave 2.6s cubic-bezier(.15,.8,.2,1) infinite}.w1{width:82px;height:82px;border-color:#ff2aa3;animation-delay:0s}.w2{width:140px;height:140px;border-color:#9b5cff;animation-delay:.55s}.w3{width:200px;height:200px;border-color:#2ad9ff;animation-delay:1.1s}.w4{width:258px;height:258px;border-color:#ff2aa3;animation-delay:1.65s}.orb.active .wave{animation:burst .7s cubic-bezier(.05,.9,.15,1) infinite}.orb.active .core{animation:core .45s ease-in-out infinite}@keyframes wave{0%{transform:scale(.28);opacity:1;filter:hue-rotate(0deg)}100%{transform:scale(1.9);opacity:0;filter:hue-rotate(300deg)}}@keyframes burst{0%{transform:scale(.22);opacity:1;filter:hue-rotate(0deg)}100%{transform:scale(2.5);opacity:0;filter:hue-rotate(360deg)}}@keyframes core{0%,100%{transform:scale(.92);filter:hue-rotate(0deg)}50%{transform:scale(1.18);filter:hue-rotate(70deg)}}
.panel{flex:1;min-height:0;background:var(--glass);border:1px solid var(--line);backdrop-filter:blur(28px) saturate(150%);-webkit-backdrop-filter:blur(28px) saturate(150%);border-radius:24px;box-shadow:0 24px 70px rgba(0,0,0,.5);overflow:hidden;display:flex;flex-direction:column}.tabs{display:grid;grid-template-columns:repeat(6,1fr);gap:5px;padding:7px;background:rgba(255,255,255,.035)}.tab{border:1px solid transparent;background:rgba(255,255,255,.045);padding:10px 4px;border-radius:13px;font-size:10px;font-weight:800;color:var(--muted);cursor:pointer}.tab.active{background:linear-gradient(135deg,rgba(255,42,163,.28),rgba(83,62,255,.25));border-color:rgba(255,255,255,.16);color:#fff}.views{position:relative;flex:1;min-height:0}.view{display:none;height:100%;padding:13px}.view.active{display:flex;flex-direction:column;gap:10px}.title{display:flex;justify-content:space-between;align-items:center;font-size:10px;letter-spacing:1.5px;color:var(--muted);font-weight:800}.scroll{flex:1;overflow:auto;white-space:pre-wrap;line-height:1.5;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;padding-right:3px}.row{display:flex;gap:7px}.input{flex:1;min-width:0;border:1px solid var(--line);background:rgba(0,0,0,.35);border-radius:14px;padding:12px;color:#fff;outline:none}.input:focus{border-color:rgba(255,42,163,.8);box-shadow:0 0 20px rgba(255,42,163,.12)}.send,.mini{border:1px solid rgba(255,255,255,.14);background:linear-gradient(135deg,rgba(255,42,163,.34),rgba(98,66,255,.3));border-radius:14px;padding:11px 14px;font-weight:800;cursor:pointer}.mini{padding:8px 10px;font-size:11px}.chips{display:flex;gap:7px;overflow:auto}.chip{white-space:nowrap;border:1px solid var(--line);background:rgba(255,255,255,.05);border-radius:999px;padding:8px 11px;font-size:11px;cursor:pointer}.two{display:grid;grid-template-columns:1fr 1fr;gap:8px}.card{border:1px solid var(--line);background:rgba(255,255,255,.045);border-radius:16px;padding:11px}.muted{color:var(--muted);font-size:11px}.vision{border:1px dashed var(--line);border-radius:16px;padding:18px;text-align:center}.preview{max-width:100%;max-height:150px;border-radius:14px;margin-top:8px;display:none}.footer{font-size:9px;text-align:center;color:#666675;padding-bottom:2px}
@media(min-width:700px){.app{padding-left:24px;padding-right:24px}.hero{min-height:340px}.orb{width:310px;height:310px}.w4{width:310px;height:310px}.w3{width:240px;height:240px}.w2{width:170px;height:170px}.w1{width:96px;height:96px}}
</style>
</head>
<body>
<canvas id="bg"></canvas><div class="noise"></div>
<div class="app">
  <div class="top"><div class="brand">PREXIS // OVERLORD</div><div class="status"><span class="dot"></span><span id="status">CLOUD ONLINE</span></div></div>
  <div class="hero"><div id="orb" class="orb" onclick="listen()"><div class="wave w1"></div><div class="wave w2"></div><div class="wave w3"></div><div class="wave w4"></div><div class="core"></div></div></div>
  <div class="panel">
    <div class="tabs">
      <button class="tab active" onclick="tab('chat',this)">CHAT</button><button class="tab" onclick="tab('tasks',this)">TÂCHES</button><button class="tab" onclick="tab('notes',this)">NOTES</button><button class="tab" onclick="tab('vision',this)">VISION</button><button class="tab" onclick="tab('local',this)">PC LOCAL</button><button class="tab" onclick="tab('tools',this)">OUTILS</button>
    </div>
    <div class="views">
      <section id="v-chat" class="view active"><div class="title"><span>SYNAPSE IA</span><span id="voiceState">JARVIS VOCAL</span></div><div id="chat" class="scroll">> PREXIS en ligne. Pose-moi une question ou touche l'orbe pour parler.</div><div class="chips"><button class="chip" onclick="quick('Cherche les dernières informations importantes aujourd’hui.')">Recherche Web</button><button class="chip" onclick="quick('Donne-moi la date et l’heure actuelles.')">Heure</button><button class="chip" onclick="quick('Aide-moi à organiser ma journée.')">Planning</button></div><div class="row"><input id="prompt" class="input" placeholder="Parle à PREXIS…" onkeydown="if(event.key==='Enter')send()"><button class="send" onclick="send()">↗</button></div></section>
      <section id="v-tasks" class="view"><div class="title"><span>MISSIONS</span><button class="mini" onclick="loadTasks()">ACTUALISER</button></div><div id="tasks" class="scroll"></div><div class="row"><input id="task" class="input" placeholder="Nouvelle tâche…"><button class="send" onclick="addTask()">+</button></div></section>
      <section id="v-notes" class="view"><div class="title"><span>MÉMOIRE PERSISTANTE</span><button class="mini" onclick="loadNotes()">ACTUALISER</button></div><div id="notes" class="scroll"></div><div class="row"><input id="note" class="input" placeholder="À retenir…"><button class="send" onclick="addNote()">+</button></div></section>
      <section id="v-vision" class="view"><div class="title"><span>VISION</span><span>IMAGE → IA</span></div><div class="vision"><input id="image" type="file" accept="image/*" capture="environment" onchange="previewImage(event)"><img id="preview" class="preview"><div class="muted">Choisis une image puis pose ta question.</div></div><div class="row"><input id="visionPrompt" class="input" placeholder="Que veux-tu analyser ?"><button class="send" onclick="analyzeImage()">ANALYSER</button></div><div id="visionOut" class="scroll"></div></section>
      <section id="v-local" class="view"><div class="title"><span>CLIENT PC</span><span id="localState">NON CONNECTÉ</span></div><div id="localOut" class="scroll">Le navigateur tente de contacter le client local sur ton PC. Seules des actions prédéfinies sont proposées.</div><div class="two"><button class="mini" onclick="localAction('system_info')">État du PC</button><button class="mini" onclick="localAction('open_calculator')">Calculatrice</button><button class="mini" onclick="localAction('open_notepad')">Bloc-notes</button><button class="mini" onclick="localAction('screenshot')">Capture écran</button></div></section>
      <section id="v-tools" class="view"><div class="title"><span>OUTILS</span><span>API CLOUD</span></div><div class="two"><div class="card"><b>☁️ Cloud</b><div class="muted">IA, mémoire, tâches, notes, recherche Web.</div></div><div class="card"><b>📱 iOS</b><div class="muted">Safari, micro, caméra et interface responsive.</div></div><div class="card"><b>💻 Local</b><div class="muted">Client PC séparé, actions limitées.</div></div><div class="card"><b>🏠 Maison</b><div class="muted">Webhook domotique optionnel.</div></div></div><button class="mini" onclick="homeCommand()">TESTER DOMOTIQUE</button><div id="toolsOut" class="scroll"></div></section>
    </div>
  </div>
  <div class="footer">PREXIS fonctionne sans écran de connexion. Ne stocke pas de mots de passe personnels dans cette version publique.</div>
</div>
<script>
const orb=document.getElementById('orb');
function pulse(ms=1200){orb.classList.add('active');setTimeout(()=>orb.classList.remove('active'),ms)}
function tab(id,btn){document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));btn.classList.add('active');document.getElementById('v-'+id).classList.add('active');pulse(600);if(id==='tasks')loadTasks();if(id==='notes')loadNotes();if(id==='local')checkLocal()}
function addChat(t){const el=document.getElementById('chat');el.textContent += '\n\n> '+t;el.scrollTop=el.scrollHeight}
function speakBrowser(text){if(!('speechSynthesis' in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='fr-FR';u.pitch=.55;u.rate=.98;const vs=speechSynthesis.getVoices();u.voice=vs.find(v=>v.lang.startsWith('fr')&&(v.name.toLowerCase().includes('thomas')||v.name.toLowerCase().includes('nicolas')||v.name.toLowerCase().includes('paul'))) || vs.find(v=>v.lang.startsWith('fr')) || null;speechSynthesis.speak(u)}
async function speak(text){try{const r=await fetch('/api/tts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});if(r.ok){const b=await r.blob();const a=new Audio(URL.createObjectURL(b));a.onplay=()=>pulse(1500);await a.play();return}}catch(e){}speakBrowser(text)}
async function send(){const i=document.getElementById('prompt'),p=i.value.trim();if(!p)return;i.value='';pulse();addChat('Traitement…');try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:p})});const d=await r.json();addChat(d.reply||d.error||'Erreur');speak(d.reply||'Erreur')}catch(e){addChat('Erreur de liaison avec le cloud.')}}
function quick(x){document.getElementById('prompt').value=x;send()}
function listen(){pulse(1800);const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert('La reconnaissance vocale n’est pas disponible dans ce navigateur.');return}const r=new SR();r.lang='fr-FR';r.interimResults=false;r.onstart=()=>document.getElementById('voiceState').textContent='ÉCOUTE…';r.onend=()=>document.getElementById('voiceState').textContent='JARVIS VOCAL';r.onresult=e=>{document.getElementById('prompt').value=e.results[0][0].transcript;send()};r.start()}
async function loadTasks(){const r=await fetch('/api/tasks');const d=await r.json();document.getElementById('tasks').textContent=d.tasks.join('\n')}
async function addTask(){const i=document.getElementById('task'),v=i.value.trim();if(!v)return;i.value='';await fetch('/api/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:v})});pulse(600);loadTasks()}
async function loadNotes(){const r=await fetch('/api/notes');const d=await r.json();document.getElementById('notes').textContent=d.notes.join('\n')}
async function addNote(){const i=document.getElementById('note'),v=i.value.trim();if(!v)return;i.value='';await fetch('/api/notes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:v})});pulse(600);loadNotes()}
let imageData='';function previewImage(e){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{imageData=r.result;const p=document.getElementById('preview');p.src=imageData;p.style.display='block'};r.readAsDataURL(f)}
async function analyzeImage(){if(!imageData){alert('Choisis une image.');return}const q=document.getElementById('visionPrompt').value.trim()||'Analyse cette image et explique ce que tu observes.';pulse(1500);const r=await fetch('/api/vision',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:q,image:imageData})});const d=await r.json();document.getElementById('visionOut').textContent=d.reply||d.error||'Erreur';if(d.reply)speak(d.reply)}
async function checkLocal(){try{const r=await fetch('http://127.0.0.1:8765/health',{mode:'cors'});if(r.ok){document.getElementById('localState').textContent='CONNECTÉ';document.getElementById('localState').style.color='var(--green)';return true}}catch(e){}document.getElementById('localState').textContent='NON CONNECTÉ';return false}
async function localAction(action){pulse(800);try{const r=await fetch('http://127.0.0.1:8765/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action})});const d=await r.json();document.getElementById('localOut').textContent='> '+(d.message||d.error||'OK');checkLocal()}catch(e){document.getElementById('localOut').textContent='> Client local non installé ou arrêté.'}}
async function homeCommand(){const r=await fetch('/api/home',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:'status'})});const d=await r.json();document.getElementById('toolsOut').textContent=d.message||d.error||'Aucun webhook configuré.'}
// fond animé
const c=document.getElementById('bg'),x=c.getContext('2d');let W,H,t=0;function resize(){W=c.width=innerWidth*devicePixelRatio;H=c.height=innerHeight*devicePixelRatio;c.style.width=innerWidth+'px';c.style.height=innerHeight+'px';x.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}addEventListener('resize',resize);resize();function bg(){t+=.008;x.clearRect(0,0,innerWidth,innerHeight);const h=innerHeight*.58;x.lineWidth=1;for(let i=-18;i<=18;i++){const xx=innerWidth/2+i*44+Math.sin(t+i)*18;x.strokeStyle=`hsla(${(t*50+i*10+260)%360},90%,65%,.12)`;x.beginPath();x.moveTo(innerWidth/2,h);x.lineTo(xx,innerHeight);x.stroke()}requestAnimationFrame(bg)}bg();
</script>
</body></html>'''


def db_conn():
    if DATABASE_URL and psycopg:
        return psycopg.connect(DATABASE_URL)
    return sqlite3.connect(os.path.join(os.path.dirname(__file__), "prexis_local.db"))


def is_pg(conn):
    return psycopg is not None and conn.__class__.__module__.startswith("psycopg")


def ph(pg):
    return "%s" if pg else "?"


def init_db():
    conn = db_conn(); pg = is_pg(conn); cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS messages (id SERIAL PRIMARY KEY, sender TEXT, content TEXT, timestamp TEXT)" if pg else "CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, content TEXT, timestamp TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS tasks (id SERIAL PRIMARY KEY, title TEXT, status TEXT, timestamp TEXT)" if pg else "CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, status TEXT, timestamp TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS notes (id SERIAL PRIMARY KEY, content TEXT, timestamp TEXT)" if pg else "CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT, timestamp TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS memories (id SERIAL PRIMARY KEY, content TEXT, timestamp TEXT)" if pg else "CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT, timestamp TEXT)")
    conn.commit(); conn.close()

init_db()


def save_message(sender, content):
    conn=db_conn(); pg=is_pg(conn); cur=conn.cursor(); q=ph(pg)
    cur.execute(f"INSERT INTO messages(sender,content,timestamp) VALUES({q},{q},{q})", (sender,content,dt.datetime.now(dt.timezone.utc).isoformat()))
    conn.commit(); conn.close()


def recent_memory():
    conn=db_conn(); pg=is_pg(conn); cur=conn.cursor(); cur.execute("SELECT content FROM memories ORDER BY id DESC LIMIT 12"); rows=cur.fetchall(); conn.close(); return [r[0] for r in rows]


def fallback_answer(prompt):
    p=prompt.lower()
    now=dt.datetime.now().astimezone()
    if any(k in p for k in ["heure","date","quel jour"]): return f"Nous sommes le {now.strftime('%d/%m/%Y')} et il est {now.strftime('%H:%M:%S')}."
    if any(k in p for k in ["bonjour","salut","coucou","hello"]): return "Bonjour. PREXIS est opérationnel. En attente de ta prochaine instruction."
    if "aide" in p: return "Je peux discuter avec toi, conserver des notes et tâches, analyser des images, effectuer des recherches Web via l'IA, parler avec une voix synthétique et utiliser le client PC local pour quelques actions prédéfinies."
    return "Le moteur IA cloud n'est pas configuré. Ajoute OPENAI_API_KEY dans Render pour activer les réponses intelligentes et la recherche Web."


def ai_answer(prompt):
    if not client: return fallback_answer(prompt)
    memories=recent_memory()
    memory_text="\n".join(f"- {m}" for m in memories) or "Aucune mémoire enregistrée."
    try:
        resp=client.responses.create(
            model=OPENAI_MODEL,
            instructions=SYSTEM_PROMPT + "\n\nMémoires récentes :\n" + memory_text,
            input=prompt,
            tools=[{"type":"web_search_preview"}],
        )
        return resp.output_text.strip() or "Je n'ai pas de réponse exploitable."
    except Exception as e:
        print("OpenAI error:",e)
        return "Le moteur IA a rencontré une erreur temporaire. Vérifie la clé API et le modèle configuré sur Render."


@app.get("/")
def index(): return render_template_string(HTML_UI)

@app.get("/api/health")
def health(): return jsonify(ok=True, cloud=bool(client), database="postgres" if DATABASE_URL else "sqlite")

@app.post("/api/chat")
def chat():
    data=request.get_json(silent=True) or {}; prompt=(data.get("prompt") or "").strip()
    if not prompt: return jsonify(error="Question vide."),400
    reply=ai_answer(prompt); save_message("User",prompt); save_message("Prexis",reply)
    return jsonify(reply=reply)

@app.get("/api/tasks")
def tasks():
    conn=db_conn(); cur=conn.cursor(); cur.execute("SELECT title,status,timestamp FROM tasks ORDER BY id DESC LIMIT 50"); rows=cur.fetchall(); conn.close()
    return jsonify(tasks=[f"• {r[0]} — {r[1]} ({r[2]})" for r in rows] or ["Aucune tâche."])

@app.post("/api/tasks")
def add_task():
    title=((request.get_json(silent=True) or {}).get("title") or "").strip()
    if title:
        conn=db_conn(); pg=is_pg(conn); cur=conn.cursor(); q=ph(pg); cur.execute(f"INSERT INTO tasks(title,status,timestamp) VALUES({q},{q},{q})",(title,"À faire",dt.datetime.now(dt.timezone.utc).isoformat())); conn.commit(); conn.close()
    return tasks()

@app.get("/api/notes")
def notes():
    conn=db_conn(); cur=conn.cursor(); cur.execute("SELECT content,timestamp FROM notes ORDER BY id DESC LIMIT 50"); rows=cur.fetchall(); conn.close()
    return jsonify(notes=[f"• {r[0]} ({r[1]})" for r in rows] or ["Aucune note."])

@app.post("/api/notes")
def add_note():
    content=((request.get_json(silent=True) or {}).get("content") or "").strip()
    if content:
        conn=db_conn(); pg=is_pg(conn); cur=conn.cursor(); q=ph(pg); now=dt.datetime.now(dt.timezone.utc).isoformat(); cur.execute(f"INSERT INTO notes(content,timestamp) VALUES({q},{q})",(content,now)); cur.execute(f"INSERT INTO memories(content,timestamp) VALUES({q},{q})",(content,now)); conn.commit(); conn.close()
    return notes()

@app.post("/api/vision")
def vision():
    data=request.get_json(silent=True) or {}; prompt=(data.get("prompt") or "Analyse cette image.").strip(); image=data.get("image") or ""
    if not image: return jsonify(error="Image manquante."),400
    if not client: return jsonify(reply="La vision IA nécessite OPENAI_API_KEY sur Render.")
    try:
        resp=client.responses.create(model=OPENAI_MODEL,instructions=SYSTEM_PROMPT,input=[{"role":"user","content":[{"type":"input_text","text":prompt},{"type":"input_image","image_url":image}]}])
        return jsonify(reply=resp.output_text.strip())
    except Exception as e:
        print("Vision error:",e); return jsonify(error="Analyse d'image indisponible."),500

@app.post("/api/tts")
def tts():
    text=((request.get_json(silent=True) or {}).get("text") or "").strip()
    if not text: return jsonify(error="Texte vide."),400
    if not client: return jsonify(error="TTS cloud non configuré."),503
    try:
        audio=client.audio.speech.create(model=TTS_MODEL,voice=TTS_VOICE,input=text,instructions="Voix française masculine, grave, calme, claire, style assistant futuriste de science-fiction.")
        data=audio.read(); return send_file(io.BytesIO(data),mimetype="audio/mpeg",download_name="prexis.mp3")
    except Exception as e:
        print("TTS error:",e); return jsonify(error="Synthèse vocale cloud indisponible."),500

@app.post("/api/home")
def home():
    webhook=os.getenv("HOME_AUTOMATION_WEBHOOK","").strip(); data=request.get_json(silent=True) or {}
    if not webhook: return jsonify(message="Aucun webhook domotique configuré. PREXIS reste en mode cloud."),200
    try:
        import requests
        r=requests.post(webhook,json=data,timeout=8); return jsonify(message=f"Webhook domotique: HTTP {r.status_code}")
    except Exception: return jsonify(error="Webhook domotique inaccessible."),502

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT",5000)),debug=False)
