import os, platform, subprocess, time
from flask import Flask, jsonify, request
from flask_cors import CORS

app=Flask(__name__)
CORS(app, resources={r"/*":{"origins":"*"}})

ALLOWED={"open_calculator","open_notepad","system_info","screenshot"}

def run_action(action):
    system=platform.system()
    if action=="system_info":
        return f"PC local connecté — {system} {platform.release()} — {platform.machine()}"
    if action=="open_calculator":
        if system=="Windows": subprocess.Popen(["calc.exe"])
        elif system=="Darwin": subprocess.Popen(["open","-a","Calculator"])
        else: subprocess.Popen(["gnome-calculator"])
        return "Calculatrice ouverte."
    if action=="open_notepad":
        if system=="Windows": subprocess.Popen(["notepad.exe"])
        elif system=="Darwin": subprocess.Popen(["open","-a","TextEdit"])
        else: subprocess.Popen(["gedit"])
        return "Éditeur de texte ouvert."
    if action=="screenshot":
        return "Capture écran : fonction prévue pour une extension locale dédiée."
    raise ValueError("Action non autorisée")

@app.get("/health")
def health(): return jsonify(ok=True,agent="PREXIS local")

@app.post("/action")
def action():
    data=request.get_json(silent=True) or {}; name=data.get("action")
    if name not in ALLOWED: return jsonify(error="Action locale non autorisée."),400
    try: return jsonify(ok=True,message=run_action(name))
    except Exception as e: return jsonify(error=f"Impossible d'exécuter l'action: {e}"),500

if __name__=="__main__": app.run(host="127.0.0.1",port=8765,debug=False)
