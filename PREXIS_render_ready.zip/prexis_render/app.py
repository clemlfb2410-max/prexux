import os, sqlite3, secrets, base64, datetime as dt
from functools import wraps
from flask import Flask, request, jsonify, render_template_string, session, redirect, url_for, send_file
import requests
from cryptography.fernet import Fernet
try:
    import psycopg
    from psycopg.rows import dict_row
except Exception:
    psycopg = None
    dict_row = None

app = Flask(__name__)
DATABASE_URL=os.getenv('DATABASE_URL','').strip()
LOCAL_DB=os.getenv('LOCAL_DB','prexis_local.db')
app.secret_key=os.getenv('SECRET_KEY') or secrets.token_hex(32)
USER=os.getenv('PREXIS_USERNAME','admin')
PASSWORD=os.getenv('PREXIS_PASSWORD','prexis-local')
OPENAI_KEY=os.getenv('OPENAI_API_KEY','').strip()
MODEL=os.getenv('OPENAI_MODEL','gpt-5')
TTS_MODEL=os.getenv('TTS_MODEL','gpt-4o-mini-tts')
TTS_VOICE=os.getenv('TTS_VOICE','onyx')
AGENT_TOKEN=os.getenv('LOCAL_AGENT_TOKEN','').strip()
HOME_WEBHOOK=os.getenv('HOME_AUTOMATION_WEBHOOK','').strip()
FERNET_KEY=os.getenv('FERNET_KEY','').strip() or Fernet.generate_key().decode()
VAULT=Fernet(FERNET_KEY.encode())
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=bool(os.getenv('RENDER')),MAX_CONTENT_LENGTH=12*1024*1024)

PROMPT='''Tu es PREXIS, un assistant personnel futuriste francophone. Réponds en français sauf demande contraire. Sois précis, utile et naturel, avec une légère ambiance IA de commandement/ninja futuriste, sans prétendre être un personnage existant. Tu peux expliquer, programmer, planifier, apprendre et analyser. Ne prétends jamais avoir exécuté une action qui ne l’a pas été. Pour les informations actuelles, utilise la recherche Web quand elle est disponible.'''

def pg(): return bool(DATABASE_URL) and psycopg is not None
def conn():
    if pg(): return psycopg.connect(DATABASE_URL.replace('postgres://','postgresql://',1),row_factory=dict_row)
    c=sqlite3.connect(LOCAL_DB); c.row_factory=sqlite3.Row; return c
def sql(s): return s.replace('?', '%s') if pg() else s
def run(q,p=(),fetch=False):
    c=conn()
    try:
        cur=c.cursor(); cur.execute(sql(q),p); rows=cur.fetchall() if fetch else []; c.commit(); return [dict(x) for x in rows]
    finally: c.close()
def init_db():
    if pg():
        ss=['CREATE TABLE IF NOT EXISTS messages(id BIGSERIAL PRIMARY KEY,sender TEXT,content TEXT,created_at TIMESTAMPTZ DEFAULT NOW())','CREATE TABLE IF NOT EXISTS tasks(id BIGSERIAL PRIMARY KEY,title TEXT,status TEXT DEFAULT \'En cours\',created_at TIMESTAMPTZ DEFAULT NOW())','CREATE TABLE IF NOT EXISTS notes(id BIGSERIAL PRIMARY KEY,content TEXT,created_at TIMESTAMPTZ DEFAULT NOW())','CREATE TABLE IF NOT EXISTS memories(id BIGSERIAL PRIMARY KEY,content TEXT,created_at TIMESTAMPTZ DEFAULT NOW())','CREATE TABLE IF NOT EXISTS vault(id BIGSERIAL PRIMARY KEY,site TEXT,username TEXT,secret TEXT,created_at TIMESTAMPTZ DEFAULT NOW())','CREATE TABLE IF NOT EXISTS local_commands(id BIGSERIAL PRIMARY KEY,command TEXT,status TEXT DEFAULT \'queued\',result TEXT DEFAULT \'\',created_at TIMESTAMPTZ DEFAULT NOW())']
    else:
        ss=['CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT,content TEXT,created_at TEXT)','CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,status TEXT DEFAULT \'En cours\',created_at TEXT)','CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT,content TEXT,created_at TEXT)','CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY AUTOINCREMENT,content TEXT,created_at TEXT)','CREATE TABLE IF NOT EXISTS vault(id INTEGER PRIMARY KEY AUTOINCREMENT,site TEXT,username TEXT,secret TEXT,created_at TEXT)','CREATE TABLE IF NOT EXISTS local_commands(id INTEGER PRIMARY KEY AUTOINCREMENT,command TEXT,status TEXT DEFAULT \'queued\',result TEXT DEFAULT \'\',created_at TEXT)']
    c=conn()
    try:
        cur=c.cursor()
        for s in ss: cur.execute(s)
        c.commit()
    finally: c.close()
init_db()

def now(): return dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
def auth(f):
    @wraps(f)
    def w(*a,**k):
        if not session.get('ok'): return jsonify(error='Authentification requise'),401
        return f(*a,**k)
    return w
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        d=request.form if request.form else (request.get_json(silent=True) or {})
        if secrets.compare_digest(str(d.get('username','')),USER) and secrets.compare_digest(str(d.get('password','')),PASSWORD):
            session['ok']=True; return redirect('/')
        return render_template_string(LOGIN,error='Identifiant ou mot de passe incorrect.')
    return render_template_string(LOGIN,error='')
@app.post('/logout')
def logout(): session.clear(); return jsonify(ok=True)

def history():
    return list(reversed(run('SELECT sender,content FROM messages ORDER BY id DESC LIMIT 12',fetch=True)))
def ai(prompt,image=None,web=False):
    if not OPENAI_KEY: return 'Le moteur IA n’est pas configuré. Ajoute OPENAI_API_KEY dans Render ou dans tes variables locales.'
    inp=[]
    for m in history(): inp.append({'role':'user' if m['sender']=='User' else 'assistant','content':m['content']})
    if image:
        inp.append({'role':'user','content':[{'type':'input_text','text':prompt or 'Analyse cette image.'},{'type':'input_image','image_url':image}]})
    else: inp.append({'role':'user','content':prompt})
    body={'model':MODEL,'instructions':PROMPT,'input':inp}
    if web: body['tools']=[{'type':'web_search'}]
    r=requests.post('https://api.openai.com/v1/responses',headers={'Authorization':'Bearer '+OPENAI_KEY,'Content-Type':'application/json'},json=body,timeout=90)
    if not r.ok: raise RuntimeError(r.text[:500])
    d=r.json()
    if d.get('output_text'): return d['output_text'].strip()
    out=[]
    for x in d.get('output',[]):
        for c in x.get('content',[]):
            if c.get('text'): out.append(c['text'])
    return '\n'.join(out).strip() or 'Réponse IA vide.'

def needs_web(p): return any(x in p.lower() for x in ['actualité','aujourd’hui','aujourd','récent','dernière','dernier','news','prix','météo','internet','web'])

@app.get('/')
def index(): return redirect('/login') if not session.get('ok') else render_template_string(UI)
@app.post('/api/interact')
@auth
def interact():
    p=str((request.get_json(silent=True) or {}).get('prompt','')).strip()
    if not p:return jsonify(error='Question vide'),400
    try:r=ai(p,web=needs_web(p))
    except Exception as e:r='Erreur du moteur IA : '+str(e)
    run('INSERT INTO messages(sender,content,created_at) VALUES(?,?,?)',('User',p,now())); run('INSERT INTO messages(sender,content,created_at) VALUES(?,?,?)',('Prexis',r,now()))
    return jsonify(reply=r)
@app.post('/api/vision')
@auth
def vision():
    f=request.files.get('image'); p=request.form.get('prompt','Analyse cette image.')
    if not f:return jsonify(error='Image manquante'),400
    raw=f.read(); url='data:'+(f.mimetype or 'image/jpeg')+';base64,'+base64.b64encode(raw).decode()
    try:return jsonify(reply=ai(p,image=url))
    except Exception as e:return jsonify(error=str(e)),502
@app.post('/api/tts')
@auth
def tts():
    text=str((request.get_json(silent=True) or {}).get('text','')).strip()
    if not OPENAI_KEY:return jsonify(error='OPENAI_API_KEY manquante'),503
    r=requests.post('https://api.openai.com/v1/audio/speech',headers={'Authorization':'Bearer '+OPENAI_KEY,'Content-Type':'application/json'},json={'model':TTS_MODEL,'voice':TTS_VOICE,'input':text[:4096],'instructions':'Voix masculine française, grave, calme, assurée et futuriste. Ne copie pas la voix d’une personne réelle.','response_format':'mp3'},timeout=90)
    if not r.ok:return jsonify(error=r.text[:500]),502
    path='/tmp/prexis.mp3'; open(path,'wb').write(r.content); return send_file(path,mimetype='audio/mpeg')

@app.get('/api/tasks')
@auth
def tasks(): return jsonify(tasks=run('SELECT id,title,status,created_at FROM tasks ORDER BY id DESC LIMIT 50',fetch=True))
@app.post('/api/tasks')
@auth
def add_task():
    x=str((request.get_json(silent=True) or {}).get('title','')).strip()
    if not x:return jsonify(error='Titre vide'),400
    run('INSERT INTO tasks(title,status,created_at) VALUES(?,?,?)',(x,'En cours',now())); return tasks()
@app.post('/api/tasks/<int:i>/done')
@auth
def done(i): run('UPDATE tasks SET status=? WHERE id=?',('Terminée',i)); return tasks()
@app.get('/api/notes')
@auth
def notes(): return jsonify(notes=run('SELECT id,content,created_at FROM notes ORDER BY id DESC LIMIT 50',fetch=True))
@app.post('/api/notes')
@auth
def add_note():
    x=str((request.get_json(silent=True) or {}).get('content','')).strip()
    if not x:return jsonify(error='Note vide'),400
    run('INSERT INTO notes(content,created_at) VALUES(?,?)',(x,now())); return notes()
@app.get('/api/memory')
@auth
def memory(): return jsonify(memory=run('SELECT id,content,created_at FROM memories ORDER BY id DESC LIMIT 50',fetch=True))
@app.post('/api/memory')
@auth
def add_memory():
    x=str((request.get_json(silent=True) or {}).get('content','')).strip()
    if not x:return jsonify(error='Mémoire vide'),400
    run('INSERT INTO memories(content,created_at) VALUES(?,?)',(x,now())); return memory()
@app.get('/api/vault')
@auth
def vault():
    out=[]
    for x in run('SELECT id,site,username,secret,created_at FROM vault ORDER BY id DESC LIMIT 50',fetch=True):
        try:s=VAULT.decrypt(x['secret'].encode()).decode()
        except:s='[illisible]'
        x['secret']=s; out.append(x)
    return jsonify(vault=out)
@app.post('/api/vault')
@auth
def add_vault():
    d=request.get_json(silent=True) or {}; site=str(d.get('site','')).strip(); user=str(d.get('username','')).strip(); sec=str(d.get('secret','')).strip()
    if not site or not sec:return jsonify(error='Site et secret requis'),400
    run('INSERT INTO vault(site,username,secret,created_at) VALUES(?,?,?,?)',(site,user,VAULT.encrypt(sec.encode()).decode(),now())); return jsonify(ok=True)
@app.post('/api/home')
@auth
def home():
    cmd=str((request.get_json(silent=True) or {}).get('command','')).strip()
    if not HOME_WEBHOOK:return jsonify(error='HOME_AUTOMATION_WEBHOOK non configuré'),503
    try:r=requests.post(HOME_WEBHOOK,json={'command':cmd},timeout=20); return jsonify(ok=r.ok,status=r.status_code,response=r.text[:500])
    except Exception as e:return jsonify(error=str(e)),502
@app.post('/api/local/queue')
@auth
def queue():
    cmd=str((request.get_json(silent=True) or {}).get('command','')).strip().lower()
    allowed=('open ','launch ','url ','notify ','volume ','lock ')
    if not cmd.startswith(allowed):return jsonify(error='Commande refusée par la liste de sécurité'),403
    run('INSERT INTO local_commands(command,status,result,created_at) VALUES(?,?,?,?)',(cmd,'queued','',now())); return jsonify(ok=True)
@app.get('/api/agent/next')
def agent_next():
    if not AGENT_TOKEN or not secrets.compare_digest(request.headers.get('X-Agent-Token',''),AGENT_TOKEN):return jsonify(error='Agent non autorisé'),401
    r=run('SELECT id,command FROM local_commands WHERE status=? ORDER BY id LIMIT 1',('queued',),fetch=True)
    if not r:return jsonify(command=None)
    run('UPDATE local_commands SET status=? WHERE id=?',('sent',r[0]['id'])); return jsonify(r[0])
@app.post('/api/agent/result')
def agent_result():
    if not AGENT_TOKEN or not secrets.compare_digest(request.headers.get('X-Agent-Token',''),AGENT_TOKEN):return jsonify(error='Agent non autorisé'),401
    d=request.get_json(silent=True) or {}; run('UPDATE local_commands SET status=?,result=? WHERE id=?',(str(d.get('status','done')),str(d.get('result',''))[:5000],int(d.get('id',0)))); return jsonify(ok=True)
@app.get('/api/status')
@auth
def status():return jsonify(ai=bool(OPENAI_KEY),database='postgresql' if pg() else 'sqlite',tts=bool(OPENAI_KEY),web=bool(OPENAI_KEY),vision=bool(OPENAI_KEY),local_agent=bool(AGENT_TOKEN),home=bool(HOME_WEBHOOK))

LOGIN='''<!doctype html><html lang="fr"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PREXIS</title><style>body{margin:0;background:#05040b;color:#fff;font-family:-apple-system,BlinkMacSystemFont,sans-serif;display:grid;place-items:center;min-height:100vh}.c{width:min(380px,88vw);padding:28px;border:1px solid #ffffff22;border-radius:28px;background:#ffffff0c;backdrop-filter:blur(25px)}input,button{width:100%;box-sizing:border-box;padding:13px;margin-top:10px;border-radius:14px;border:1px solid #ffffff22;background:#ffffff0b;color:#fff}button{background:#8d35ff;border:0;font-weight:700}.e{color:#ff789c;margin-top:10px}</style><div class="c"><h1>PREXIS</h1><p>OVERLORD // AUTHENTIFICATION</p><form method="post"><input name="username" placeholder="Identifiant" required><input name="password" type="password" placeholder="Mot de passe" required><button>ENTRER</button></form>{%if error%}<div class="e">{{error}}</div>{%endif%}</div>'''
UI='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PREXIS</title><style>*{box-sizing:border-box}body{margin:0;background:#03030a;color:#fff;font-family:-apple-system,BlinkMacSystemFont,sans-serif}.s{width:min(760px,94vw);margin:auto;padding:14px}.top{display:flex;justify-content:space-between}.brand{letter-spacing:4px;font-weight:800}.pill,.tab,.input,.btn,.item,.chip{border:1px solid #ffffff18;background:#ffffff0b;color:#fff;border-radius:14px}.pill{padding:8px;font-size:10px}.orb{width:250px;height:250px;margin:20px auto;display:grid;place-items:center;position:relative;cursor:pointer}.core{width:74px;height:74px;border-radius:50%;background:radial-gradient(circle,#fff,#ff49bf 35%,#7429ff 70%,#081026);box-shadow:0 0 50px #ff22c8,0 0 110px #6b22ff,0 0 150px #00c8ff;animation:g 1.5s infinite}.w{position:absolute;border:3px solid;border-radius:50%;animation:w 2.3s linear infinite}.a{width:90px;height:90px;border-color:#ff168d}.b{width:145px;height:145px;border-color:#9a2cff;animation-delay:.5s}.c{width:200px;height:200px;border-color:#00bfff;animation-delay:1s}.d{width:250px;height:250px;border-color:#ff20e8;animation-delay:1.5s}.active .w{animation-duration:.5s}@keyframes w{from{transform:scale(.3);opacity:1}to{transform:scale(1.9);opacity:0;filter:hue-rotate(360deg)}}@keyframes g{50%{transform:scale(1.2);filter:hue-rotate(180deg)}}.card{padding:14px;border-radius:24px;background:#ffffff0a;border:1px solid #ffffff18;backdrop-filter:blur(28px)}.tabs{display:grid;grid-template-columns:repeat(6,1fr);gap:5px}.tab{padding:10px 3px;font-size:10px}.tab.on{background:#9a2fff44}.panel{display:none}.panel.on{display:block}.out{min-height:170px;max-height:330px;overflow:auto;white-space:pre-wrap;padding:10px;line-height:1.5}.row{display:flex;gap:7px;margin-top:8px}.input{flex:1;padding:12px;outline:0}.btn{padding:12px 14px;background:#9636ff;font-weight:800}.list{display:grid;gap:7px;margin-top:10px}.item{padding:10px}.chips{display:flex;gap:7px;flex-wrap:wrap}.chip{padding:10px}small{opacity:.6}@media(max-width:500px){.tabs{grid-template-columns:repeat(3,1fr)}.orb{width:220px;height:220px}.d{width:220px;height:220px}.c{width:175px;height:175px}}</style><div class="s"><div class="top"><div class="brand">PREXIS</div><div class="pill" id="st">...</div></div><div class="orb" id="orb" onclick="listen()"><div class="w a"></div><div class="w b"></div><div class="w c"></div><div class="w d"></div><div class="core"></div></div><div class="card"><div class="tabs"><button class="tab on" onclick="tab('chat',this)">CHAT</button><button class="tab" onclick="tab('tasks',this)">TÂCHES</button><button class="tab" onclick="tab('notes',this)">NOTES</button><button class="tab" onclick="tab('memory',this)">MÉMOIRE</button><button class="tab" onclick="tab('vision',this)">VISION</button><button class="tab" onclick="tab('tools',this)">OUTILS</button></div><section id="chat" class="panel on"><h4>SYNAPSE IA</h4><div id="out" class="out">PREXIS en ligne.</div><div class="row"><input id="p" class="input" placeholder="Pose une question..." onkeydown="if(event.key==='Enter')send()"><button class="btn" onclick="send()">GO</button></div></section><section id="tasks" class="panel"><h4>PLANNING</h4><div id="tl" class="list"></div><div class="row"><input id="ti" class="input" placeholder="Tâche"><button class="btn" onclick="addTask()">+</button></div></section><section id="notes" class="panel"><h4>NOTES</h4><div id="nl" class="list"></div><div class="row"><input id="ni" class="input" placeholder="Note"><button class="btn" onclick="addNote()">+</button></div></section><section id="memory" class="panel"><h4>MÉMOIRE</h4><div id="ml" class="list"></div><div class="row"><input id="mi" class="input" placeholder="À retenir"><button class="btn" onclick="addMemory()">+</button></div></section><section id="vision" class="panel"><h4>VISION</h4><input id="im" type="file" accept="image/*" class="input"><div class="row"><input id="vp" class="input" placeholder="Que dois-je analyser ?"><button class="btn" onclick="vision()">GO</button></div><div id="vo" class="out"></div></section><section id="tools" class="panel"><h4>OUTILS</h4><div class="chips"><button class="chip" onclick="ask('Quelle est la date et l’heure ?')">Date/heure</button><button class="chip" onclick="ask('Que peux-tu faire ?')">Capacités</button><button class="chip" onclick="speak('PREXIS opérationnel. Noyau vocal en ligne.')">Test vocal</button></div><p><small>Cloud : IA, recherche Web, mémoire, tâches, notes, vision et TTS. Local : agent PC autorisé.</small></p><button class="btn" onclick="logout()">DÉCONNEXION</button></section></div></div><script>const $=x=>document.getElementById(x),orb=$('orb');async function api(u,o={}){let r=await fetch(u,o);if(r.status==401){location='/login';return}let d=await r.json();if(!r.ok)throw Error(d.error||'Erreur');return d}function pulse(){orb.classList.add('active');setTimeout(()=>orb.classList.remove('active'),800)}function tab(id,b){document.querySelectorAll('.panel').forEach(x=>x.classList.remove('on'));$(id).classList.add('on');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));b.classList.add('on');if(id=='tasks')loadTasks();if(id=='notes')loadNotes();if(id=='memory')loadMemory();pulse()}async function send(){let p=$('p').value.trim();if(!p)return;$('p').value='';$('out').textContent='> Analyse...';pulse();try{let d=await api('/api/interact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:p})});$('out').textContent='> '+d.reply;speak(d.reply)}catch(e){$('out').textContent=e.message}}function ask(x){$('p').value=x;send()}function browserSpeak(t){if(!('speechSynthesis'in window))return;speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(t);u.lang='fr-FR';u.pitch=.55;u.rate=.96;speechSynthesis.speak(u)}async function speak(t){try{let r=await fetch('/api/tts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:t})});if(!r.ok){browserSpeak(t);return}let a=new Audio(URL.createObjectURL(await r.blob()));a.play().catch(()=>browserSpeak(t))}catch(e){browserSpeak(t)}}function listen(){pulse();let R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R){$('out').textContent='Micro non disponible dans ce navigateur.';return}let r=new R();r.lang='fr-FR';$('out').textContent='> Écoute...';r.onresult=e=>{$('p').value=e.results[0][0].transcript;send()};r.start()}async function loadTasks(){let d=await api('/api/tasks');$('tl').innerHTML=d.tasks.map(x=>`<div class="item"><b>${esc(x.title)}</b><br>${esc(x.status)}</div>`).join('')}async function addTask(){let x=$('ti').value.trim();if(!x)return;await api('/api/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:x})});$('ti').value='';loadTasks()}async function loadNotes(){let d=await api('/api/notes');$('nl').innerHTML=d.notes.map(x=>`<div class="item">${esc(x.content)}</div>`).join('')}async function addNote(){let x=$('ni').value.trim();if(!x)return;await api('/api/notes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:x})});$('ni').value='';loadNotes()}async function loadMemory(){let d=await api('/api/memory');$('ml').innerHTML=d.memory.map(x=>`<div class="item">${esc(x.content)}</div>`).join('')}async function addMemory(){let x=$('mi').value.trim();if(!x)return;await api('/api/memory',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:x})});$('mi').value='';loadMemory()}async function vision(){let f=$('im').files[0];if(!f)return;$('vo').textContent='> Analyse...';let fd=new FormData();fd.append('image',f);fd.append('prompt',$('vp').value||'Analyse cette image.');try{let d=await api('/api/vision',{method:'POST',body:fd});$('vo').textContent=d.reply;speak(d.reply)}catch(e){$('vo').textContent=e.message}}async function logout(){await fetch('/logout',{method:'POST'});location='/login'}function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}async function st(){try{let d=await api('/api/status');$('st').textContent=(d.ai?'IA ON':'IA OFF')+' · '+d.database.toUpperCase()}catch(e){}}st();</script></html>'''
